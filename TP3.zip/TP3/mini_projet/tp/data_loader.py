from typing import List
import logging

logger = logging.getLogger(__name__)


def load_notes() -> List[float]:
    """
    Charge une liste de notes simulées.

    Returns:
        List[float]: liste de notes
    """
    logger.info("Chargement des notes")
    return [12.5, 15.0, 9.0, 18.0, 14.5]
