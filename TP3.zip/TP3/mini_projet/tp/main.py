import logging
from tp.data_loader import load_notes
from tp.stats import compute_average, find_min, find_max


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)


def main() -> None:
    """
    Point d'entrée du mini-projet.
    """
    logging.info("Démarrage du mini-projet")

    notes = load_notes()
    moyenne = compute_average(notes)
    note_min = find_min(notes)
    note_max = find_max(notes)

    logging.info(f"Moyenne : {moyenne}")
    logging.info(f"Note min : {note_min}")
    logging.info(f"Note max : {note_max}")


if __name__ == "__main__":
    main()
