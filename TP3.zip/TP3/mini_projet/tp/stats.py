from typing import List
import logging

logger = logging.getLogger(__name__)


def compute_average(notes: List[float]) -> float:
    """
    Calcule la moyenne des notes.

    Args:
        notes (List[float]): liste de notes

    Returns:
        float: moyenne
    """
    logger.debug("Calcul de la moyenne")
    return sum(notes) / len(notes)


def find_min(notes: List[float]) -> float:
    """
    Trouve la plus petite note.

    Args:
        notes (List[float]): liste de notes

    Returns:
        float: note minimale
    """
    return min(notes)


def find_max(notes: List[float]) -> float:
    """
    Trouve la plus grande note.

    Args:
        notes (List[float]): liste de notes

    Returns:
        float: note maximale
    """
    return max(notes)
