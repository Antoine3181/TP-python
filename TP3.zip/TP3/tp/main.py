import logging
from tp.api import fetch_post


logging.basicConfig(
    level=logging.DEBUG, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def main() -> None:
    """
    Point d'entrée principal du programme.
    """
    logging.info("Démarrage du programme")

    post = fetch_post(1)

    logging.info("Affichage du post")
    logging.debug(f"Contenu du post : {post}")


if __name__ == "__main__":
    main()
