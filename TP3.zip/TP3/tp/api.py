from typing import Dict
import logging

logger = logging.getLogger(__name__)


def fetch_post(post_id: int) -> Dict:
    """
    Récupère un post simulé à partir de son identifiant.

    Args:
        post_id (int): identifiant du post

    Returns:
        Dict: dictionnaire représentant un post
    """
    logger.debug(f"Début de fetch_post avec post_id={post_id}")

    post = {
        "userId": 1,
        "id": post_id,
        "title": "Post de test",
        "body": "Ceci est un faux post pour le TP.",
    }

    logger.info("Post récupéré avec succès")
    return post
